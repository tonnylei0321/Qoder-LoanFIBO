# FIBO × SASAC-GOV × CMB 三层信贷本体 — GraphDB 导入说明

## 文件说明
- `fibo_sasac_cmb_ontology.ttl`：主本体文件，Turtle 格式，UTF-8 编码
- 三元组总数：621 条
- OWL 类：75 个 | 属性：12 个 | 实例：48 个

---

## GraphDB 导入步骤

### 1. 创建专用命名图（推荐）
在 GraphDB Workbench → SPARQL 中执行：
```sparql
CREATE GRAPH <urn:graph:cmb-credit-ontology>
```

### 2. 导入 TTL 文件
方式A：Workbench UI
  → Import → Upload RDF files → 选择 fibo_sasac_cmb_ontology.ttl
  → Named Graph: urn:graph:cmb-credit-ontology
  → Encoding: UTF-8 → Import

方式B：REST API
```bash
curl -X POST \
  "http://localhost:7200/repositories/YOUR_REPO/statements" \
  -H "Content-Type: text/turtle; charset=UTF-8" \
  -H "X-GraphDB-Named-Graph: urn:graph:cmb-credit-ontology" \
  --data-binary @fibo_sasac_cmb_ontology.ttl
```

### 3. 验证导入
```sparql
# 统计各命名空间类的数量
SELECT ?ns (COUNT(?class) AS ?count)
WHERE {
  GRAPH <urn:graph:cmb-credit-ontology> {
    ?class a owl:Class .
    BIND(REPLACE(STR(?class), "(#|/)[^#/]*$", "") AS ?ns)
  }
}
GROUP BY ?ns
ORDER BY DESC(?count)
```

---

## 三层架构说明

| 层级 | 前缀 | 职责 | 三元组数 |
|------|------|------|---------|
| 第一层 FIBO 标准层 | `fibo-fnd:` `fibo-be:` | OWL2-DL 标准类锚点，提供跨机构语义互操作基础 | 73 |
| 第二层 SASAC-GOV 扩展层 | `sasac:` `scf:` | 中国监管特色扩展（五篇大文章、隐债、MPA）+ ERP字段映射规则 | 280 |
| ERP 映射层 | `erp-sap:` `erp-yonyou:` `erp-kingdee:` | 数据表/字段定义 + SQL取数表达式 | 114 |
| 第三层 CMB 私有层 | `cmb:` | 行业差异化阈值、评分权重模型、打标规则、客户实例 | 154 |

---

## ERP 字段映射使用方法

查询某指标的 SAP 取数表达式：
```sparql
SELECT ?indicator ?sql ?filter
WHERE {
  GRAPH <urn:graph:cmb-credit-ontology> {
    ?mapping a sasac:ERPFieldMapping ;
             sasac:mapsToIndicator ?indicator ;
             sasac:sqlExpression ?sql ;
             sasac:erpVendor erp-sap:SAP_S4HANA .
    OPTIONAL { ?mapping sasac:filterCondition ?filter }
  }
}
```

查询某客户的五篇大文章标签：
```sparql
SELECT ?tag ?value
WHERE {
  GRAPH <urn:graph:cmb-credit-ontology> {
    cmb:Customer_HuaYuan ?tag ?value .
    FILTER(CONTAINS(STR(?tag), "Tag") || CONTAINS(STR(?tag), "Flag"))
  }
}
```

查询行业差异化阈值：
```sparql
SELECT ?metric ?threshold
WHERE {
  GRAPH <urn:graph:cmb-credit-ontology> {
    cmb:RealEstateSectorProfile ?metric ?threshold .
    FILTER(CONTAINS(STR(?metric), "cmbchina"))
  }
}
```

---

## 扩展建议

1. **新增ERP厂商映射**：在 `erp-yonyou:` 或 `erp-kingdee:` 命名空间下参照 SAP 映射模式补充
2. **新增行业阈值档案**：参照 `cmb:RealEstateSectorProfile` 模式创建新行业实例
3. **新增客户实例**：参照 `cmb:Customer_HuaYuan` 模式，关联对应的评分模型和行业档案
4. **对接 FIBO 完整本体**：如需完整 FIBO OWL2-DL 语义，可从 https://spec.edmcouncil.org/fibo/ 下载完整本体后与本文件一同导入 GraphDB，两者通过 `rdfs:subClassOf` 自动关联
